#include "FreeRTOS.h"
#include "queue.h"

extern QueueHandle_t GraphQueue;
void init_GraphQueue(void);
