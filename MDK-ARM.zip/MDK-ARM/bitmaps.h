#include <stdlib.h>

#include "GUI.h"


extern GUI_CONST_STORAGE GUI_BITMAP bmclock_view_bmp; //Clock Icon

extern GUI_CONST_STORAGE GUI_BITMAP bmconfig_view_bmp;//Config Icon

extern GUI_CONST_STORAGE GUI_BITMAP bmclock_base_bmp; //Clock Image

extern GUI_CONST_STORAGE GUI_BITMAP bmlittle_bracket_bmp; //Little Clock bracket

extern GUI_CONST_STORAGE GUI_BITMAP bmtest; //Test

